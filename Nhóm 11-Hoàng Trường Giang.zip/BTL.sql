CREATE DATABASE QuanLyBaiHat;
USE QuanLyBaiHat;

CREATE TABLE DiaDVD (
    MaDia CHAR(10) PRIMARY KEY,
    TenDia VARCHAR(100)
)
CREATE TABLE DongNhac (
    MaDongNhac CHAR(10) PRIMARY KEY,
    TenDongNhac VARCHAR(100)
)
CREATE TABLE BaiHat (
    MaBaiHat CHAR(10) PRIMARY KEY,
    TenBaiHat VARCHAR(100),
    TacGia VARCHAR(100),
    NamSangTac INT,
    TheLoai VARCHAR(50),
    MaDongNhac CHAR(10) NOT NULL,
    FOREIGN KEY (MaDongNhac) REFERENCES DongNhac(MaDongNhac)
)
CREATE TABLE CaSi (
    MaCaSi CHAR(10) PRIMARY KEY,
    TenCa VARCHAR(100)
)
CREATE TABLE PhoiKhi (
    MaPhoiKhi CHAR(10) PRIMARY KEY,
    NguoiPhoiKhi VARCHAR(100)
)
CREATE TABLE Dia_BaiHat (
    MaDia CHAR(10),
    MaBaiHat CHAR(10),
    PRIMARY KEY (MaDia, MaBaiHat),
    FOREIGN KEY (MaDia) REFERENCES DiaDVD(MaDia),
    FOREIGN KEY (MaBaiHat) REFERENCES BaiHat(MaBaiHat)
)
CREATE TABLE BaiHat_CaSi (
    MaBaiHat CHAR(10),
    MaCaSi CHAR(10),
    PRIMARY KEY (MaBaiHat, MaCaSi),
    FOREIGN KEY (MaBaiHat) REFERENCES BaiHat(MaBaiHat),
    FOREIGN KEY (MaCaSi) REFERENCES CaSi(MaCaSi)
)
CREATE TABLE BaiHat_PhoiKhi (
    MaBaiHat CHAR(10),
    MaPhoiKhi CHAR(10),
    PRIMARY KEY (MaBaiHat, MaPhoiKhi),
    FOREIGN KEY (MaBaiHat) REFERENCES BaiHat(MaBaiHat),
    FOREIGN KEY (MaPhoiKhi) REFERENCES PhoiKhi(MaPhoiKhi)
)
CREATE TRIGGER trg_DeleteBaiHat
ON BaiHat
INSTEAD OF DELETE
AS
BEGIN
    DELETE FROM BaiHat_CaSi WHERE MaBaiHat IN (SELECT MaBaiHat FROM deleted);
    DELETE FROM BaiHat_PhoiKhi WHERE MaBaiHat IN (SELECT MaBaiHat FROM deleted);
    DELETE FROM Dia_BaiHat WHERE MaBaiHat IN (SELECT MaBaiHat FROM deleted);
    DELETE FROM BaiHat WHERE MaBaiHat IN (SELECT MaBaiHat FROM deleted);
END
CREATE LOGIN User1 WITH PASSWORD = 'MatKhau123'
USE QuanLyBaiHat
CREATE USER User1 FOR LOGIN User1

ALTER ROLE db_datareader ADD MEMBER User1
ALTER ROLE db_datawriter ADD MEMBER User1
GRANT EXECUTE TO User1
GRANT SELECT, INSERT, UPDATE, DELETE ON BaiHat TO User1

BACKUP DATABASE QuanLyBaiHat 
TO DISK = 'C:\Backup\QuanLyBaiHat.bak'
WITH FORMAT, INIT, NAME = 'Full Backup of QuanLyBaiHat'